class AppConstant{
 static const String  baseImage="https://image.tmdb.org/t/p/w500/";
}