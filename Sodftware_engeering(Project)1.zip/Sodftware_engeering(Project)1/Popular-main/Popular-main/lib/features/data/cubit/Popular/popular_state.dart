
abstract class PopularState {}

class PopularInitial extends PopularState {}
class Popularloading extends PopularState {}
class PopularLoaded extends PopularState {}
class Popularerror extends PopularState {}
