
abstract class PopularImageState {}

class PopularImageInitial extends PopularImageState {}
class PopularImageloaded extends PopularImageState {}
class PopularImageLoading extends PopularImageState {}
class PopularImageError extends PopularImageState {}
