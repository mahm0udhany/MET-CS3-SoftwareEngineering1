
abstract class PopularInfoState {}

class PopularInfoInitial extends PopularInfoState {}
class PopularInfoloading extends PopularInfoState {}
class PopularInfoLoaded extends PopularInfoState {}
class Popularinfoerror extends PopularInfoState {}
class PopularImageloaded extends PopularInfoState {}
class PopularImageLoading extends PopularInfoState {}
class PopularImageError extends PopularInfoState {}
